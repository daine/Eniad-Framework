<?php
abstract class E_View extends Core{
	
}